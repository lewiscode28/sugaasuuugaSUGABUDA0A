AFRAME.registerComponent("create-markers", {
  
  //Add Code Here!
  
  });
